import java.awt.print.Book;
import java.util.Scanner;

class BookstoreManager {
    private static Book[] inventory = new Book[10]; // An array to store up to 10 books
    private static int count = 0; // To keep track of how many books are in the inventory

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        do {
            System.out.println("Bookstore Inventory Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addBook(scanner);
                    break;
                case 2:
                    removeBook(scanner);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 3);
    }

    // Method to add a new book to the inventory
    public static void addBook(Scanner scanner) {
        if (count >= inventory.length) {
            System.out.println("Inventory is full. Cannot add more books.");
            return;
        }

        System.out.print("Enter ISBN: ");
        String isbn = scanner.nextLine();
        System.out.print("Enter Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Author: ");
        String author = scanner.nextLine();
        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        System.out.print("Is Available (true/false): ");
        boolean available = scanner.nextBoolean();

        inventory[count] = new Book();
        count++;
        System.out.println("Book added successfully!");
    }

    // Method to remove a book from the inventory
    public static void removeBook(Scanner scanner) {
        System.out.print("Enter ISBN of the book to remove: ");
        String isbn = scanner.nextLine();
        for (int i = 0; i < count; i++) {
            if (inventory[i].equals(isbn)) {
                // Shift the remaining books left
                for (int j = i; j < count - 1; j++) {
                    inventory[j] = inventory[j + 1];
                }
                inventory[count - 1] = null; // Clear the last book
                count--;
                System.out.println("Book removed successfully.");
                return;
            }
        }
        System.out.println("Book not found.");
    }


}